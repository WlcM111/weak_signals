"""Тесты сервиса collector."""
