"""Репозитории PostgreSQL (схема `collector`)."""
