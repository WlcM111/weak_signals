"""Тесты сервиса orchestrator."""
