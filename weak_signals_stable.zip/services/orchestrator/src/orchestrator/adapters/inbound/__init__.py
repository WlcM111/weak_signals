"""Входящие адаптеры orchestrator."""
