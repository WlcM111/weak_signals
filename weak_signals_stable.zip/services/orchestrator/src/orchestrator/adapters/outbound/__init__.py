"""Исходящие адаптеры orchestrator."""
